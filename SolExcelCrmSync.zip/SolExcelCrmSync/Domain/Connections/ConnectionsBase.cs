﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;

namespace SolExcelCrmSync.Containers.Connections
{
    public class ConnectionsBase
    {
        public void addConnection(Entity firstEntity, Entity secondEntity)
        {
            
        }
    }
}
